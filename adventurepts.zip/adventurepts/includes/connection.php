<?php
    $conn = mysqli_connect('localhost', 'karim', 'Karim@01', 'logistics');
?>